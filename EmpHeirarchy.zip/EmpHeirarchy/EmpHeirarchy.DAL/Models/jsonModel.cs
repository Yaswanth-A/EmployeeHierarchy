﻿namespace EmpHeirarchy.DAL.Models
{
    public class jsonModel
    {
        public string Source { get; set; }
        public string Target { get; set; }
    }
}
